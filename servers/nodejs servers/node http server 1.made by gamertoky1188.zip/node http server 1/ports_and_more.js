const ports = [{ port1: 2020 }];

module.exports = { ports };
